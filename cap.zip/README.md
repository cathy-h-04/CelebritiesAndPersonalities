# CelebritiesAndPersonalities

The Cap (Celebrities and personalities) App matches users with celebrities based on similarities between them. 

# Background

Our group decided to take on this project because of how we were fascinated by whether we could come up with a more accurate way of matching people with celebrities than buzzfeed quizzes. We are also interested in ways of understanding personalities. So, we got to work and decided on three main components of our matching algorithm. We use 1) MBTI type, 2) enneagram type, and 3) name analysis in order to provide our custom match with celebrities. 

# How to Run Cap App

# Explanatory Video

Here is the link to our explanatory video for our project: LINK HERE